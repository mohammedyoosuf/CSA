/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class MedicalRecord {  // Holds comprehensive medical information about patients, covering diagnoses, treatments, and other relevant data.
    public String patients;
    public String coveringdiagnoses;
    public String treatment;
    public String medicaldata;
    
    
     public MedicalRecord(String patients, String coveringdiagnoses, String treatment, String medicaldata) {
        this.patients = patients;
        this.coveringdiagnoses = coveringdiagnoses;
        this.treatment = treatment;
        this.medicaldata = medicaldata;
    }
    
      public String getPatients() {
        return patients;
    }

    public void setPatients(String patients) {
        this.patients = patients;
    }

    public String getCoveringdiagnoses() {
        return coveringdiagnoses;
    }

    public void setCoveringdiagnoses(String coveringdiagnoses) {
        this.coveringdiagnoses = coveringdiagnoses;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getMedicaldata() {
        return medicaldata;
    }

    public void setMedicaldata(String medicaldata) {
        this.medicaldata = medicaldata;
    }
    
}
