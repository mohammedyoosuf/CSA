/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Appointment {   //Represents scheduled appointments between patients and doctors, including details like date, time, and associated participants.
    public int Date;
    public int time;
    public String participant;
    
      public Appointment(int date, int time, String participant) {
        Date = date;
        this.time = time;
        this.participant = participant;
    }
    
     public int getDate() {
        return Date;
    }

    public void setDate(int date) {
        Date = date;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public String getParticipant() {
        return participant;
    }

    public void setParticipant(String participant) {
        this.participant = participant;
    }
}
