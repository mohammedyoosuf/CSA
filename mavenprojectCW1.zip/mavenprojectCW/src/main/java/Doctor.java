/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Doctor extends Person{ // Also extends the Person entity to include information about healthcare professionals, including their specialization and contact details.
    public String proffessional;
    public String contactdetails;
    public String specialization;
    
     public Doctor(String proffessional, String contactdetails, String specialization) {
        super(1, "John", "Doe");
        this.proffessional = proffessional;
        this.contactdetails = contactdetails;
        this.specialization = specialization;
    }

    
    public String getProffessional() {
        return proffessional;
    }

    public void setProffessional(String proffessional) {
        this.proffessional = proffessional;
    }

    public String getContactdetails() {
        return contactdetails;
    }

    public void setContactdetails(String contactdetails) {
        this.contactdetails = contactdetails;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    
}
