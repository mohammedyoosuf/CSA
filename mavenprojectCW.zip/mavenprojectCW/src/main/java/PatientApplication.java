
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class PatientApplication extends ResourceConfig{
    public PatientApplication(){
    register(BillingResources.class);
     property(ServerProperties.TRACING, "ALL");
    }
    
}
