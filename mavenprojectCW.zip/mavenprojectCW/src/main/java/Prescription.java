/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Prescription { //Records information about prescribed medications, including dosage, instructions, and duration.
    public String instruction;
    public String dosage;
    public String medication;
    public String duration;
    
    
    
    
     public Prescription(String instruction, String dosage, String medication, String duration) {
        this.instruction = instruction;
        this.dosage = dosage;
        this.medication = medication;
        this.duration = duration;
    }
        public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public String getMedication() {
        return medication;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

   
    
    
}
