
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class PatientDAO {
     private static Map<Integer, Patient> patient = new HashMap<>();
    private static AtomicInteger medicalcounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(PatientDAO.class.getName());
    static {
        patient.put(1, new Patient("dr", "John", "good"));
        patient.put(2, new Patient("dr", "Alice", "bad"));
        patient.put(3, new Patient("dr", "Bob","good"));
    }

    public static Map<Integer, Patient> getPatient() {
        try {
            return patient;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static Patient findPatient(int id) {
        try {
            return patient.get(id);
        } catch (Exception e) {
            e.printStackTrace();
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static int generatePatient() {
        try {
            return medicalcounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return -1;
        }
    }

    public static void addPatient(Patient patientObj) {
        try {
            int newId = generatePatient();
            patientObj.setId(newId);
            patient.put(newId, patientObj);
        } catch (Exception e) {
         LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void updateMedical(int id, Patient updatepatient) {
        try {
            if (patient.containsKey(id)) {
                updatepatient.setId(id);
                patient.put(id, updatepatient);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void deletePatient(int id) {
        try {
            patient.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            //    LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
        }
    }
    
}
