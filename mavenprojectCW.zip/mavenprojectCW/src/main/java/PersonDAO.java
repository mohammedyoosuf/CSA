/*
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
/*
public class PersonDAO {
    private static  Map<Integer, Person> person = new HashMap<>();
    private static AtomicInteger personid = new AtomicInteger(0);
    
    static{
         person.put(1, new Person(1, "John", "Doe"));
        person.put(2, new Person(2, "Alice","Smith"));
        person.put(3, new Person(3, "Bob", "Johnson"));
    
    }
      public static Map<Integer, Person> getperson() {
        return person;
    }

    public static Person findpersonById(int id) {
        return person.get(id);
    }

    public static int generatId() {
        int maxId = 0;
        for (Person person : person.values()) {
            maxId = Math.max(maxId,person.getId());
        }
        return maxId + 1;
    }

    public static void addperson(Person Person) {
        int newId = generatId();
        Person.setId(newId);
        person.put(newId, Person);
    }

    public static void updateperson(int id, Person updatedStudent) {
        if (person.containsKey(id)) {
            updatedStudent.setId(id);
            person.put(id, updatedStudent);
        }
    }

    public static void deleteperson(int id) {
        person.remove(id);
    }

  
}



*/
import static java.lang.Math.log;
import static java.lang.StrictMath.log;

import static java.rmi.server.LogStream.log;
import java.util.HashMap;
//import java.util.logging.Level;
import java.util.logging.*;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class PersonDAO {
    private static Map<Integer, Person> person = new HashMap<>();
    private static AtomicInteger personIdCounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(PersonDAO.class.getName());
    static {
        person.put(1, new Person(1, "John", "Doe"));
        person.put(2, new Person(2, "Alice", "Smith"));
        person.put(3, new Person(3, "Bob", "Johnson"));
    }

    public static Map<Integer, Person> getPatient() {
        try {
            return person;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            return null;
        }
    }

    public static Person findPersonById(int id) {
        try {
            return person.get(id);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            return null;
        }
    }

    public static int generateId() {
        try {
            return personIdCounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            return -1;
        }
    }

    public static void addPerson(Person personObj) {
        try {
            int newId = generateId();
            personObj.setId(newId);
            person.put(newId, personObj);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            e.printStackTrace();
        }
    }

    public static void updatePerson(int id, Person updatedPerson) {
        try {
            if (person.containsKey(id)) {
                updatedPerson.setId(id);
                person.put(id, updatedPerson);
            }
        } catch (Exception e) {
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            e.printStackTrace();
        }
    }

    public static void deletePerson(int id) {
        try {
            person.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
             LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            //  LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);            
        }
    }
}

