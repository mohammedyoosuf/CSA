/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class PersonDAO {
    private static Map<Integer, Person> person = new HashMap<>();
    private static AtomicInteger personid = new AtomicInteger(0);
    
    static{
         person.put(1, new Person(1, "John", "Doe"));
        person.put(2, new Person(2, "Alice","Smith"));
        person.put(3, new Person(3, "Bob", "Johnson"));
    
    }
      public static Map<Integer, Person> getperson() {
        return person;
    }

    public static Person findpersonById(int id) {
        return person.get(id);
    }

    public static int generatId() {
        int maxId = 0;
        for (Person person : persons.values()) {
            maxId = Math.max(maxId,person.getId());
        }
        return maxId + 1;
    }

    public static void addperson(Person Person) {
        int newId = generateId();
        Person.setId(newId);
        persons.put(newId, Person);
    }

    public static void updateperson(int id, Person updatedStudent) {
        if (persons.containsKey(id)) {
            updatedStudent.setId(id);
            persons.put(id, updatedStudent);
        }
    }

    public static void deleteperson(int id) {
        persons.remove(id);
    }

    static Person findpersonById(int userId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
