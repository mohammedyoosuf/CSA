
import java.util.Collection;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class PatientResouces {
       @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/all")
    public Collection<Patient> getPatient() {
        return PatientDAO.getPatient().values();
    }

    // Get a specific student by ID
    @GET
    @Path("{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBillingId(@PathParam("userId") int pat) {
        
        Patient patient = PatientDAO.findPatient(pat);

        if (patient != null) {
            return Response.status(Response.Status.OK).entity(patient).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    // Create new student
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("/create")
    public Response createPatient(Patient newpat) {
        
        PatientDAO.addPatient(newpat);
        return Response.status(Response.Status.CREATED)
                .entity("Student created successfully.")
                .build();
    }

    // Update student
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("/update/{userId}")
    public Response updateMedical(@PathParam("userId") int userId, Patient updatmed) {
        
        PatientDAO.updateMedical(userId, updatmed);
        return Response.status(Response.Status.OK)
                .entity("Student updated successfully.")
                .build();
    }

    // Delete student
    @DELETE
    @Path("/delete/{userId}")
    public Response deletePatient(@PathParam("userId") int patId) {
        
        PatientDAO.deletePatient(patId);
        return Response.status(Response.Status.OK).entity("Student deleted successfully.").build();
    }
    
}
