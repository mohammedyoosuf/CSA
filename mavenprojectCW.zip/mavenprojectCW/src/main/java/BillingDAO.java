
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class BillingDAO {
     private static Map<Integer, Billing> billing = new HashMap<>();
    private static AtomicInteger billingCounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(BillingDAO.class.getName());
    static {
        billing.put(1, new Billing(1, "John", 1));
        billing.put(2, new Billing(2, "Alice", 2));
        billing.put(3, new Billing(3, "Bob",3));
    }

    public static Map<Integer, Billing> getBilling() {
        try {
            return billing;
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static Billing findPersonById(int id) {
        try {
            return billing.get(id);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static int generateBIlling() {
        try {
            return billingCounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return -1;
        }
    }

    public static void addBilling(Billing billingObj) {
        try {
            int newId = generateBIlling();
            billingObj.setId(newId);
            billing.put(newId, billingObj);
        } catch (Exception e) {
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void updateBilling(int id, Billing updatedbilling) {
        try {
            if (billing.containsKey(id)) {
                updatedbilling.setId(id);
                billing.put(id, updatedbilling);
            }
        } catch (Exception e) {
       LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void deleteBilling(int id) {
        try {
            billing.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
             LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);  
        }
    }
}
