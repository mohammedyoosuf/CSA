
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class MedicalDAO {
    private static Map<Integer, Medical> medical = new HashMap<>();
    private static AtomicInteger medicalcounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(MedicalDAO.class.getName());
    static {
        medical.put(1, new Medical("dr", "John", "good"));
        medical.put(2, new Medical("dr", "Alice", "bad"));
        medical.put(3, new Medical("dr", "Bob","good"));
    }

    public static Map<Integer, Medical> getMedical() {
        try {
            return medical;
        } catch (Exception e) {
            e.printStackTrace();
     LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static Medical findMedicald(int id) {
        try {
            return medical.get(id);
        } catch (Exception e) {
            e.printStackTrace();
      LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static int generateMedical() {
        try {
            return medicalcounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return -1;
        }
    }

    public static void addMedical(Medical medicalObj) {
        try {
            int newId = generateMedical();
            medicalObj.setId(newId);
            medical.put(newId, medicalObj);
        } catch (Exception e) {
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void updateMedical(int id, Medical updateMedical) {
        try {
            if (medical.containsKey(id)) {
                updateMedical.setId(id);
                medical.put(id, updateMedical);
            }
        } catch (Exception e) {
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void deleteMedical(int id) {
        try {
            medical.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
        }
    }
}
