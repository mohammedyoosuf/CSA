/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Medical {
    public String name;
    public String comment;
    public String status;
    
    
    public Medical(String name, String comment, String status) {
        this.name = name;
        this.comment = comment;
        this.status = status;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for contact
    public String getComment() {
        return comment;
    }

    // Setter for contact
    public void setComment(String comment) {
        this.comment = comment;
    }

    // Getter for status
    public String getStatus() {
        return status;
    }

    // Setter for status
    public void setStatus(String status) {
        this.status = status;
    }
}
