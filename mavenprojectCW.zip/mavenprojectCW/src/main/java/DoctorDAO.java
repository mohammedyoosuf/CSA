
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class DoctorDAO {
     private static Map<Integer, Doctor> doctor = new HashMap<>();
    private static AtomicInteger billingCounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(PersonDAO.class.getName());
    static {
        doctor.put(1, new Doctor("dr", "John", "skin"));
        doctor.put(2, new Doctor("dr", "Alice", "skin"));
        doctor.put(3, new Doctor("dr", "Bob","skin"));
    }

    public static Map<Integer, Doctor> getDoctor() {
        try {
            return doctor;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static Doctor findDoctorId(int id) {
        try {
            return doctor.get(id);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }

    public static int generateDoctor() {
        try {
            return billingCounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
         LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return -1;
        }
    }

    public static void addDoctor(Doctor doctorObj) {
        try {
            int newId = generateDoctor();
            doctorObj.setId(newId);
            doctor.put(newId, doctorObj);
        } catch (Exception e) {
        LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void updateDoctor(int id, Doctor updatedocotor) {
        try {
            if (doctor.containsKey(id)) {
                updatedocotor.setId(id);
                doctor.put(id, updatedocotor);
            }
        } catch (Exception e) {
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void deleteDoctor(int id) {
        try {
            doctor.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
        }
    }
}
