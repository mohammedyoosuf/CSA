/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
/**
 *
 * @author User
 */
public class PersonApplication extends ResourceConfig{
    public PersonApplication() {
        register(PersonResources.class);
        
        property(ServerProperties.TRACING, "ALL");
    }
}
