
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class PrescriptionDAO {
       private static Map<Integer, Prescription> prescription = new HashMap<>();
    private static AtomicInteger prescriptioncounter = new AtomicInteger(3);
    private static final Logger LOGGER = Logger.getLogger(PatientDAO.class.getName());
    static {
        prescription.put(1, new Prescription("dr", "John", "good",""));
        prescription.put(2, new Prescription("dr", "Alice", "bad",""));
        prescription.put(3, new Prescription("dr", "Bob","good",""));
    }

    public static Map<Integer, Prescription> getprescription() {
        try {
            return prescription;
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            return null;
        }
    }

    public static Prescription findprescription(int id) {
        try {
            return prescription.get(id);
        } catch (Exception e) {
            e.printStackTrace();
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
          return null;
        }
    }

    public static int generateprescription() {
        try {
            return prescriptioncounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            return -1;
        }
    }

    public static void addprescription(Prescription prescripobj) {
        try {
            int newId = generateprescription();
            prescripobj.setId(newId);
            prescription.put(newId, prescripobj);
        } catch (Exception e) {
          
            e.printStackTrace();
        }
    }

    public static void updateprescription(int id, Prescription updateprescription) {
        try {
            if (prescription.containsKey(id)) {
                updateprescription.setId(id);
                prescription.put(id, updateprescription);
            }
        } catch (Exception e) {
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
            e.printStackTrace();
        }
    }

    public static void deleteprescription(int id) {
        try {
            prescription.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e);
             
        }
    }
    
}
