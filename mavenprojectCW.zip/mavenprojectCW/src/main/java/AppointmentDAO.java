
import static PersonDAO.generateId;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class AppointmentDAO {
      private static Map<Integer, Appointment> appointment = new HashMap<>();
      private static AtomicInteger AppointmentCounter = new AtomicInteger(3);
      private static final Logger LOGGER = Logger.getLogger(AppointmentDAO.class.getName());
      
      
      static {
        appointment.put(1, new Appointment(1, 1, "Doe"));
        appointment.put(2, new Appointment(2, 2, "Smith"));
        appointment.put(3, new Appointment(3, 3, "Johnson"));
    }
      public static Map<Integer, Appointment> getAppointment() {
        try {
            return appointment;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }
      public static Appointment findAppointmentByparticipent(String id) {
        try {
            return appointment.get(id);
        } catch (Exception e) {
            e.printStackTrace();
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return null;
        }
    }
      public static int generate() {
        try {
            return AppointmentCounter.incrementAndGet();
        } catch (Exception e) {
            e.printStackTrace();
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            return -1;
        }
    }

       public static void addApp(Appointment appObj) {
        try {
            int newId = generate();
            appObj.setId(newId);
            appointment.put(newId, appObj);
        } catch (Exception e) {
             LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void updateAppointment(int id, Appointment updatedapp) {
        try {
            if (appointment.containsKey(id)) {
                updatedapp.setId(id);
                appointment.put(id, updatedapp);
            }
        } catch (Exception e) {
           LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
            e.printStackTrace();
        }
    }

    public static void deletePerson(int id) {
        try {
            appointment.remove(id);
        } catch (Exception e) {
            e.printStackTrace();
          LOGGER.log(Level.SEVERE, "Error occurred while getting persons", e); 
        }
    }
      
      
      
      
      
}
