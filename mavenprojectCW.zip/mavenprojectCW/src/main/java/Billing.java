/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Billing {//Manages financial transactions related to healthcare services, including invoices, payments, and outstanding balances.
    public int payment;
    public String invoice;
    public int outstandingbalance;
    
    
    
    public Billing(int payment, String invoice, int outstandingbalance) {
        this.payment = payment;
        this.invoice = invoice;
        this.outstandingbalance = outstandingbalance;
    }
    
    
    
    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public int getOutstandingbalance() {
        return outstandingbalance;
    }

    public void setOutstandingbalance(int outstandingbalance) {
        this.outstandingbalance = outstandingbalance;
    }
    
}
